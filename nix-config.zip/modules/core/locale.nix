{ config, pkgs, ... }:

{
  time.timeZone = "Europe/Rome";

  i18n.defaultLocale = "en_US.UTF-8";

  console.keyMap = "us";
}

